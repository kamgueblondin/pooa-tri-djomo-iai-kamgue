/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tri;

/**
 *
 * @author Solomon IMIRI
 */
public class Tri_class {
    // Tri par sélection

  private  int N = 10;

  private int[] a = {701, 301, 132, 57, 23, 10, 4, 1};          // Le tableau à trier 
  

  public void Impression() {
      for (int i = 0; i < N; ++i)
          try{
              System.out.print (" " + a[i] + " ");
              System.out.println ("");
          }catch(ArrayIndexOutOfBoundsException e){}
          
  }

  public void TriSelection() {
      int   min, t;

      for (int i = 0; i < N - 1; ++i) {
          min = i;
          for (int j = i+1; j < N; ++j)
             if (a[j] < a[min])
                 min = j; 
          t = a[min]; a[min] = a[i]; a[i] = t;
      }
  }

  public void TriBulle() {
  // Tri bulle

    int   t;

    for (int i = N-1; i >= 0; --i) 
        for (int j = 1; j <= i; ++j)
            if (a[j-1] > a[j]) {
                t = a[j-1]; a[j-1] = a[j]; a[j] = t;
            }
  }

  public void TriInsertion() {
  // Tri par insertion 
    int   j, v;

    for (int i = 1; i < N; ++i) {
        try{
        v = a[i]; j = i;
        while (j > 0  &&  a[j-1] > v) {
            a[j] = a[j-1]; 
            --j;
        }
        a[j] = v;
        }catch(ArrayIndexOutOfBoundsException e){}
    }
  }

  public void TriShell() {
  // Tri Shell
    int   h;

    h = 1; do 
       h = 3*h + 1; 
    while ( h <= N );
    do {
        h = h / 3;
        for (int i = h; i < N; ++i)
            try{
                if (a[i] < a[i-h]) {
                int   v = a[i], j = i;
                do {
                    a[j] = a[j-h];
                    j = j - h;
                } while (j >= h  &&  a[j-h] > v);
                a[j] = v;
            }
            }catch(ArrayIndexOutOfBoundsException e){
            
            }
    } while ( h > 1);
  }
}
