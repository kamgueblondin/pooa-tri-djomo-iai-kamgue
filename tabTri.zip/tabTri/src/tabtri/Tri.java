/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tabtri;

import java.util.Vector;

/**
 *
 * @author Blondin
 */
public class Tri {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TriShell tc = new TriShell();
        String tableau[] = {"blondin", "jordan", "franckiine", "delineni", "auriele", "celine"};
        String tableauCopy[] = tableau;
        Vector vectTaille = new Vector();
        for (int it = 0; it < tableau.length; it++) {
            vectTaille.add(new Long(tableau[it].length()));
        }
        Long[] tabTaille = (Long[]) vectTaille.toArray(new Long[vectTaille.size()]);
        int valeurTaille = tc.sort(tabTaille);

        Vector vecTraduit = new Vector();
        Long copyTabTraduit[] = null;
        for (int itra = 0; itra < tableau.length; itra++) {
            vecTraduit.add(Tri.traduire(tableau[itra].substring(0, valeurTaille)));
        }

        Long[] tabTraduit = (Long[]) vecTraduit.toArray(new Long[vecTraduit.size()]);

        tc.printArray(tabTraduit);

        tc.sort(tabTraduit);

        tc.printArray(tabTraduit);

        copyTabTraduit = (Long[]) vecTraduit.toArray(new Long[vecTraduit.size()]);
        //Affichage du resultat
        Vector tableau_vide = new Vector();
        for (int aucon = 0; aucon < copyTabTraduit.length; aucon++) {
            for (int con = 0; con < tc.l.length; con++) {
                if (copyTabTraduit[con].equals(tc.l[aucon])) {
                    tableau_vide.add(tableauCopy[con]);
                }
            }
        }

        //Affichage du résultat
        String inter[] = new String[tableau_vide.size()];
        tableau_vide.copyInto(inter);

        for (int i = 0; i < inter.length; i++) {
            System.out.print(inter[i] + " ");
        }
        System.out.println();

    }

    public static Long traduire(String msg) {
        msg = msg.toUpperCase();
        String s = "";
        Long d = null;
        int res = 0;
        char[] lettres = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
        int[] chiffres = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26};
        int[] ent = null;
        int len = msg.length();
        for (int x = 0; x < len; x++) {
            char c = (char) (msg.charAt(x));
            for (int deb = 0; deb < lettres.length; deb++) {
                if (c == lettres[deb]) {
                    try {
                        res += chiffres[deb];
                    } catch (NullPointerException npe) {
                    }
                    if (chiffres[deb] < 10) {
                        s += "0" + chiffres[deb];
                    } else {
                        s += chiffres[deb];
                    }
                }
            }
            try {
                d = Long.parseLong(s);
            } catch (NumberFormatException e) {
            }
            try {
                try {
                    ent[x] = Integer.parseInt(s);
                } catch (NumberFormatException nf) {
                }
            } catch (NullPointerException ne) {
            }
        }
        return d;
    }

}
