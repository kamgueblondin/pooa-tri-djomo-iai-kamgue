/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tri;

/**
 *
 * @author Blondin
 */
public class Tri {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String str = "salad ede";
        //String a=Tri.traduire(str);
        Long d = null;
        try{
            //d=Long.parseLong(a);
        }catch(NumberFormatException e){}
        try{char c=(char)d.intValue();}catch(NullPointerException np){}
        TriShell tc=new TriShell();
        //System.out.println(d);
        Long arr[]= { Tri.traduire("blondin"), Tri.traduire("jordan"), Tri.traduire("franck"), Tri.traduire("auriele")};
        
        System.out.println("Array Avant le shell sort"); 
        tc.printArray(arr); 
        tc.sort(arr); 
  
        System.out.println("Array après le shell sort"); 
        tc.printArray(arr); 
       
    }
 
    public static Long traduire(String msg){
    msg=msg.toUpperCase();
    String s = "";
    Long d = null;
    int[] ent = null;
    int len = msg.length();
    for(int x = 0; x < len; x++){
        int c = (int)(msg.charAt(x));
        if (c > 'z'){
            s += (int)(msg.charAt(x) - (26));
        }else{
            s += (int)(msg.charAt(x));
        }
        try{
            d=Long.parseLong(s);
        }catch(NumberFormatException e){}
        try{
            try{ent[x]=Integer.parseInt(s);}catch(NumberFormatException nf){}
        }catch(NullPointerException ne){}
    }
    return d;
}
    
}
