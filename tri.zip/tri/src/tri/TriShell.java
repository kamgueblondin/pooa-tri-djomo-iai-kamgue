/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tri;

/**
 *
 * @author Blondin
 */
public class TriShell {
    public void printArray(Long arr[]) 
    { 
        int n = arr.length; 
        for (int i=0; i<n; ++i) 
            System.out.print(arr[i] + " "); 
        System.out.println(); 
    }
    public int sort(Long arr[]) 
    { 
        int n = arr.length; 
  
        for (int gap = n/2; gap > 0; gap /= 2) 
        { 
            
            for (int i = gap; i < n; i += 1) 
            { 
                
                Long temp = arr[i]; 

                int j; 
                for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) 
                    arr[j] = arr[j - gap]; 
                
                arr[j] = temp; 
            } 
        } 
        return 0; 
    } 
}
