/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testtri;

import java.util.*;
/**
 *
 * @author Blondin
 */
public class TestTri {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     Vector VV=new Vector();
   	 String saisie;

   	 do
   	 {
            System.out.println("entrez un nouvel nom:");
            saisie=sc.nextLine();
            VV.add(saisie);
   	 }
   	 while(!saisie.equals("0"));
   	 System.out.println("vous avez saisie 0 fin de saisie:");

         String inter[]=new String[VV.size()];
         VV.copyInto(inter);

     Arrays.sort(inter);
     for(int i=1;i<inter.length;i++)
     {
    	 System.out.println(inter[i]);
     }
    }
    
}
